#!/bin/sh
buildroot-aarch64/output/host/bin/aarch64-buildroot-linux-gnu-gcc -O2 -std=gnu90 -D_NO_SSE2 -DHAVE_PTHREAD -static *.c -o bwa062-kern38-gcc92-aarch64 -lm -pthread
buildroot-aarch64/output/host/bin/aarch64-buildroot-linux-gnu-strip bwa062-kern38-gcc92-aarch64
buildroot-aarch32/output/host/bin/arm-buildroot-linux-gnueabihf-gcc -O2 -std=gnu90 -D_NO_SSE2 -DHAVE_PTHREAD -static *.c -o bwa062-kern32-gcc92-aarch32-armv7 -lm -pthread
buildroot-aarch32/output/host/bin/arm-buildroot-linux-gnueabihf-strip bwa062-kern32-gcc92-aarch32-armv7
buildroot-aarch32-noneon/output/host/usr/bin/arm-buildroot-linux-gnueabi-gcc -O2 -std=gnu90 -D_NO_SSE2 -DHAVE_PTHREAD -static *.c -o bwa062-kern32-gcc92-aarch32-armv6 -lm -pthread
buildroot-aarch32-noneon/output/host/usr/bin/arm-buildroot-linux-gnueabi-strip bwa062-kern32-gcc92-aarch32-armv6
buildroot-i686/output/host/usr/bin/i686-buildroot-linux-gnu-gcc -O2 -std=gnu90 -D_NO_SSE2 -DHAVE_PTHREAD -static *.c -o bwa062-kern38-gcc92-x64 -lm -pthread
buildroot-i686/output/host/usr/bin/i686-buildroot-linux-gnu-strip bwa062-kern38-gcc92-x64
buildroot-x64/output/host/usr/bin/x86_64-buildroot-linux-gnu-gcc -O2 -std=gnu90 -D_NO_SSE2 -DHAVE_PTHREAD -static *.c -o bwa062-kern32-gcc92-i686 -lm -pthread
buildroot-x64/output/host/usr/bin/x86_64-buildroot-linux-gnu-strip bwa062-kern32-gcc92-i686
