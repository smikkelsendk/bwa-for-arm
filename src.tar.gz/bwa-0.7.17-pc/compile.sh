#!/bin/sh
buildroot-i686/output/host/usr/bin/i686-buildroot-linux-gnu-gcc  -O2 -std=gnu90 -DHAVE_PTHREAD -static *.c -o bwa0717-kern38-gcc92-x64 -lm -pthread -lrt
buildroot-i686/output/host/usr/bin/i686-buildroot-linux-gnu-strip bwa0717-kern38-gcc92-x64
buildroot-x64/output/host/usr/bin/x86_64-buildroot-linux-gnu-gcc -O2 -std=gnu90 -DHAVE_PTHREAD -static *.c -o bwa0717-kern32-gcc92-i686 -lm -pthread -lrt
buildroot-x64/output/host/usr/bin/x86_64-buildroot-linux-gnu-strip bwa0717-kern32-gcc92-i686
