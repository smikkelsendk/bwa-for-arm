#!/bin/sh
buildroot-aarch64/output/host/bin/aarch64-buildroot-linux-gnu-gcc  -O2 -std=gnu90 -DHAVE_PTHREAD -static *.c -o bwa0717-kern38-gcc92-aarch64 -lm -pthread -lrt
buildroot-aarch64/output/host/bin/aarch64-buildroot-linux-gnu-strip bwa0717-kern38-gcc92-aarch64
buildroot-aarch32/output/host/bin/arm-buildroot-linux-gnueabihf-gcc -O2 -std=gnu90 -DHAVE_PTHREAD -static *.c -o bwa0717-kern32-gcc92-aarch32-armv7 -lm -pthread -lrt
buildroot-aarch32/output/host/bin/arm-buildroot-linux-gnueabihf-strip bwa0717-kern32-gcc92-aarch32-armv7
clang -O2 -target arm64-apple-macos11 -std=gnu90 -DHAVE_PTHREAD  *.c -o bwa0717-mac-aarch64 -lm -lz -pthread
